	<div class="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-5 liste-pages-footer">
					<h4>StudExpo.com</h4>
					<p>
						Nihil morati post haec militares avidi saepe turbarum adorti sunt Montium primum, qui divertebat in proximo, levi corpore senem atque morbosum, et hirsutis resticulis cruribus eius innexis divaricaturn sine spiramento ullo ad usque praetorium traxere praefecti.
					</p>
					<p>Phone : <span class="coordonnees">123 456 789</span></p>
					<p>Email : <span class="coordonnees">infos@studexpo.com</span></p>

				</div>
				<div class="col-md-3 liste-pages-footer middle">
					<h4>A propos</h4>
					<ul>
						<li><a href="">Qui sommes nous ?</a></li>
						<li><a href="">Notre équipe</a></li>
						<li><a href="">Témoignages</a></li>
						<li><a href="">Contact</a></li>
					</ul>
				</div>
				<div class="col-md-3 liste-pages-footer">
					<h4>Help</h4>
					<ul>
						<li><a href="">Mentions légales</a></li>
						<li><a href="">Site Map</a></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="footer__copyright">
			<div class="container">
				<div class="copyright">&copy; StudExpo - All Rights Reserved</div>
				<div class="btn-network network-footer">
					<a href="" target="_blank"><i class="fa fa-facebook"></i></a>
					<a href="" target="_blank"><i class="fa fa-twitter"></i></a>
					<a href="" target="_blank"><i class="fa fa-google-plus"></i></a>
					<a href="" target="_blank"><i class="fa fa-rss"></i></a>
				</div>
			</div>
		</div>
	</div>
